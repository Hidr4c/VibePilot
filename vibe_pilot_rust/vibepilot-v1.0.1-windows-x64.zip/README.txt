# VibePilot v1.0.0

Visual AI Automation Orchestrator for Windows.

## Installation
1. Download vibepilot.exe
2. Run directly (no installer needed)

## Requirements
- Windows 10/11
- A local LLM server (LM Studio, Ollama, or OpenAI-compatible API)

## License
MIT
Full documentation: https://github.com/Hidr4c/VibePilot
